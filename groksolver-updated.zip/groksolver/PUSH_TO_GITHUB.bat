@echo off
chcp 65001 >nul
cd /d "%~dp0"
where git >nul 2>nul || (echo Git is not installed. Download: https://git-scm.com/download/win & pause & exit /b 1)
echo Pushing DotsSolver update to GitHub...
git push origin main
echo.
echo Done. Vercel will redeploy groksolver.vercel.app in 1-2 minutes.
pause
